<?php include './partials/layouts/layoutTop3.php' ?>

<header class="site-header aximo-header-section site-header--menu-center bg-light7" id="sticky-menu">
    <div class="container">
        <nav class="navbar site-navbar">
            <!-- Brand Logo-->
            <div class="brand-logo">
                <a href="index.php">
                    <img src="assets/images/logo/logo-dark.svg" alt="" class="light-version-logo">
                </a>
            </div>
            <div class="menu-block-wrapper">
                <div class="menu-overlay"></div>
                <nav class="menu-block" id="append-menu-header">
                    <div class="mobile-menu-head">
                        <div class="go-back">
                            <i class="fa fa-angle-left"></i>
                        </div>
                        <div class="current-menu-title"></div>
                        <div class="mobile-menu-close">&times;</div>
                    </div>
                    <ul class="site-menu-main">
                        <li class="nav-item nav-item-has-children">
                            <a href="#" class="nav-link-item drop-trigger">Demo <i class="fas fa-angle-down"></i></a>
                            <ul class="sub-menu" id="submenu-1">
                                <li class="sub-menu--item">
                                    <a href="index.php">
                                        <span class="menu-item-text">Design Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-02.php">
                                        <span class="menu-item-text">Startup Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-03.php">
                                        <span class="menu-item-text">SEO Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-04.php">
                                        <span class="menu-item-text">Business Consultation</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-05.php">
                                        <span class="menu-item-text">Digital Marketing</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-06.php">
                                        <span class="menu-item-text">Interior Design Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-07.php">
                                        <span class="menu-item-text">Advertising agency</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a href="about-us.php" class="nav-link-item">About Us</a>
                        </li>
                        <li class="nav-item nav-item-has-children">
                            <a href="#" class="nav-link-item drop-trigger">Pages <i class="fas fa-angle-down"></i></a>
                            <ul class="sub-menu" id="submenu-2">
                                <li class="sub-menu--item">
                                    <a href="about-us.php">
                                        <span class="menu-item-text">About Us</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="pricing.php">
                                        <span class="menu-item-text">Pricing</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">blog <i class="fas fa-angle-down"></i></a>
                                    <ul class="sub-menu shape-none" id="submenu-3">
                                        <li class="sub-menu--item">
                                            <a href="blog.php">
                                                <span class="menu-item-text">Our Blog</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="blog-grid.php">
                                                <span class="menu-item-text">Blog grid</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-blog.php">
                                                <span class="menu-item-text">blog details</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Service<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-4">
                                        <li class="sub-menu--item">
                                            <a href="service.php">
                                                <span class="menu-item-text">service</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-service.php">
                                                <span class="menu-item-text">service details</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Team<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-5">
                                        <li class="sub-menu--item">
                                            <a href="team.php">
                                                <span class="menu-item-text">team</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-team.php">
                                                <span class="menu-item-text">team details</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Portfolio<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-6">
                                        <li class="sub-menu--item">
                                            <a href="portfolio-02.php">
                                                <span class="menu-item-text">Portfolio One Column</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="portfolio-01.php">
                                                <span class="menu-item-text">Portfolio Two Column</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-portfolio.php">
                                                <span class="menu-item-text">Single Portfolio</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Utility<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-7">
                                        <li class="sub-menu--item">
                                            <a href="faq.php">
                                                <span class="menu-item-text">faq</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="errors-404.php">
                                                <span class="menu-item-text">Error 404</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="testimonial.php">
                                                <span class="menu-item-text">testimonial</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="coming-soon.php">
                                                <span class="menu-item-text">Coming Soon</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Account<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-8">
                                        <li class="sub-menu--item">
                                            <a href="sign-up.php">
                                                <span class="menu-item-text">sign up</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="sign-in.php">
                                                <span class="menu-item-text">sign in</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="reset-password.php">
                                                <span class="menu-item-text">reset password</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item nav-item-has-children">
                            <a href="#" class="nav-link-item drop-trigger">Blog <i class="fas fa-angle-down"></i></a>
                            <ul class="sub-menu" id="submenu-9">
                                <li class="sub-menu--item">
                                    <a href="blog.php">
                                        <span class="menu-item-text">blog</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="blog-grid.php">
                                        <span class="menu-item-text">Blog grid</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="single-blog.php">
                                        <span class="menu-item-text">blog Details</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a href="contact-us.php" class="nav-link-item">Contact Us</a>
                        </li>
                    </ul>
                </nav>
            </div>

            <div class="header-btn header-btn-l1 ms-auto d-none d-xs-inline-flex">
                <a class="aximo-default-btn pill aximo-header-btn green-btn" href="contact-us.php">
                    Contact Us
                </a>
            </div>
            <!-- mobile menu trigger -->
            <div class="mobile-menu-trigger">
                <span></span>
            </div>
            <!--/.Mobile Menu Hamburger Ends-->
        </nav>
    </div>
</header>
<!--End landex-header-section -->

<div class="aximo-hero-section5 bg-light7 position-relative">
    <div class="container">
        <div class="aximo-hero-content6 overflow-hidden">
            <div class="aximo-hero-title">
                <div class="aximo-hero-text">Tailored interior</div>
                <div class="aximo-marquee-one">
                    <div class="aximo-infinite">
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                        <a href=""><img src="assets/images/v6/next.svg" alt=""></a>
                    </div>
                </div>
            </div>
            <div class="aximo-hero-title">
                <div class="aximo-hero-text">design</div>
                <img src="assets/images/v6/image.png" alt="">
                <div class="aximo-hero-text"> that speaks</div>
            </div>
            <div class="aximo-hero-title">
                <div class="aximo-hero-text">to your style</div>
                <div class="aximo-marquee-two">
                    <div class="aximo-infinite two">
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                        <a href="">to your style <img src="assets/images/v6/next-white.svg" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="aximo-p-shape z-index">
        <img src="assets/images/v6/shapes2.png" alt="">
    </div>
</div>
<!-- End sction -->

<div class="aximo-video-section2 extra-side-margin wow fadeInUpX" data-wow-delay="0s">
    <img src="assets/images/v6/video-bg.png" alt="">
    <a class="aximo-video-popup play-btn-size video-init" href="https://www.youtube.com/watch?v=7e90gBu4pas">
        <img src="assets/images/v6/play-btn.png" alt="">
        <div class="waves waves6 wave-1"></div>
        <div class="waves waves6 wave-2"></div>
        <div class="waves waves6 wave-3"></div>
    </a>
    <div class="aximo-video-shape">
        <img src="assets/images/v5/shape2.png" alt="">
    </div>
</div>
<!-- End section -->

<div class="section aximo-section-padding2">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="aximo-iconbox-wrap7 wow fadeInUpX" data-wow-delay="0.1s">
                    <div class="aximo-iconbox-icon7">
                        <img src="assets/images/v6/imagebox1.png" alt="">
                    </div>
                    <div class="aximo-iconbox-data7">
                        <h3>Aesthetic Design</h3>
                        <p>Demonstrates a keen eye for design, ensuring each project reflects a high level of aesthetic appeal.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="aximo-iconbox-wrap7 wow fadeInUpX" data-wow-delay="0.2s">
                    <div class="aximo-iconbox-icon7">
                        <img src="assets/images/v6/imagebox2.png" alt="">
                    </div>
                    <div class="aximo-iconbox-data7">
                        <h3>Affordable Pricing</h3>
                        <p>We always ensure a balance between affordability and also delivering a high-quality end product.</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6 offset-lg-0 offset-md-3">
                <div class="aximo-iconbox-wrap7 wow fadeInUpX" data-wow-delay="0.3s">
                    <div class="aximo-iconbox-icon7">
                        <img src="assets/images/v6/imagebox3.png" alt="">
                    </div>
                    <div class="aximo-iconbox-data7">
                        <h3>Professional Team</h3>
                        <p>We boast of a team of skilled interior designers, architects & support staff with functional experience</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="aximo-bottom-center">
            <a class="aximo-default-btn green-btn pill" href="service.php"><span>Explore More Features</span> </a>
        </div>
    </div>
</div>
<!-- end -->

<div class="section dark-bg2 aximo-section-padding position-relative">
    <div id="aximo-counter"></div>
    <div class="container">
        <div class="aximo-section-title light playfair center max-width-xl">
            <h2>We are professional interior design experts</h2>
        </div>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-lg-6 order-lg-2 wow fadeInUpX" data-wow-delay="0.1s">
                <div class="aximo-v6-thumb1">
                    <img src="assets/images/v6/thumb-v6-1.png" alt="">
                </div>
            </div>
            <div class="col-lg-6 d-flex align-items-center">
                <div class="aximo-default-content-wrap">
                    <div class="aximo-default-content light large">
                        <p>We are an experienced interior design firm offering a professional service specializing in creating and also enhancing interior spaces for residential, commercial or other types of buildings.</p>
                        <p>We are a team of skilled and quality interior designers who are trained and skilled in the art and science of designing spaces to meet the functional and aesthetic needs of our clients.</p>
                    </div>
                    <div class="aximo-counter-wrap6">
                        <div class="aximo-counter-data6 wow fadeInUpX" data-wow-delay="0.1s">
                            <h2><span data-percentage="15" class="aximo-counter"></span>+</h2>
                            <p>Years of work <br> experience</p>
                        </div>
                        <div class="aximo-counter-data6 wow fadeInUpX" data-wow-delay="0.2s">
                            <h2><span data-percentage="2" class="aximo-counter"></span>k</h2>
                            <p>successful <br> projects done</p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="aximo-footer-shape">
        <img src="assets/images/v6/shapes.png" alt="">
    </div>
</div>
<!-- End section -->

<div class="section dark-bg2 aximo-section-padding6">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 wow fadeInUpX" data-wow-delay="0.1s">
                <div class="aximo-v6-thumb2">
                    <img src="assets/images/v6/thumb-v6-2.png" alt="">
                </div>
            </div>
            <div class="col-lg-6 d-flex align-items-center">
                <div class="aximo-default-content light large">
                    <p>We work on various projects including homes, offices, retail spaces, and our services include space planning, furniture selection, color coordination, lighting design, and overall aesthetic enhancement.</p>
                    <p>Our goal is to transform interiors into functional, comfortable, and aesthetically pleasing environments that reflect the client's preferences and lifestyle.</p>
                    <div class="aximo-extra-mt">
                        <a class="aximo-default-btn green-btn pill shadow-white" href="contact-us.php"><span>Read Our Story</span> </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End section -->

<div class="section aximo-section-padding4">
    <div class="container">
        <div class="row aximo_screenfix_right">
            <div class="swiper aximo-iconbox-slider">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="aximo-section-title playfair">
                            <h2>Professional interior design solutions</h2>
                        </div>
                    </div>
                </div>

                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="aximo-iconbox-wrap8 cornflower-bg">
                            <div class="aximo-iconbox-icon8">
                                <img src="assets/images/v6/icon-v-6-1.png" alt="">
                            </div>
                            <div class="aximo-iconbox-data8">
                                <h3>Residential Interior Design</h3>
                                <p>Tailored home design solutions that reflect the client's lifestyle, preferences, and functional needs.</p>
                                <a href="single-service.php">
                                    <img src="assets/images/v6/arrow-dark.svg" alt="">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-iconbox-wrap8 bg-light7">
                            <div class="aximo-iconbox-icon8">
                                <img src="assets/images/v6/icon-v-6-2.png" alt="">
                            </div>
                            <div class="aximo-iconbox-data8">
                                <h3>Commercial Interior Design</h3>
                                <p>Office design solutions focusing on functionality, color, productivity, and a professional aesthetic look.</p>
                                <a href="single-service.php">
                                    <img src="assets/images/v6/arrow-dark.svg" alt="">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-iconbox-wrap8 green-bg2">
                            <div class="aximo-iconbox-icon8">
                                <img src="assets/images/v6/icon-v-6-3.png" alt="">
                            </div>
                            <div class="aximo-iconbox-data8 light">
                                <h3>Space Planning</h3>
                                <p>Space planning, furniture selection, color coordination, to create inviting and personalized interiors.</p>
                                <a href="single-service.php">
                                    <img src="assets/images/v6/arrow-white.svg" alt="">
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-slide">
                        <div class="aximo-iconbox-wrap8 cornflower-bg">
                            <div class="aximo-iconbox-icon8">
                                <img src="assets/images/v6/icon-v-6-1.png" alt="">
                            </div>
                            <div class="aximo-iconbox-data8">
                                <h3>Residential Interior Design</h3>
                                <p>Tailored home design solutions that reflect the client's lifestyle, preferences, and functional needs.</p>
                                <a href="single-service.php">
                                    <img src="assets/images/v6/arrow-dark.svg" alt="">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-iconbox-wrap8 bg-light7">
                            <div class="aximo-iconbox-icon8">
                                <img src="assets/images/v6/icon-v-6-2.png" alt="">
                            </div>
                            <div class="aximo-iconbox-data8">
                                <h3>Commercial Interior Design</h3>
                                <p>Office design solutions focusing on functionality, color, productivity, and a professional aesthetic look.</p>
                                <a href="single-service.php">
                                    <img src="assets/images/v6/arrow-dark.svg" alt="">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-iconbox-wrap8 green-bg2">
                            <div class="aximo-iconbox-icon8">
                                <img src="assets/images/v6/icon-v-6-3.png" alt="">
                            </div>
                            <div class="aximo-iconbox-data8 light">
                                <h3>Space Planning</h3>
                                <p>Space planning, furniture selection, color coordination, to create inviting and personalized interiors.</p>
                                <a href="single-service.php">
                                    <img src="assets/images/v6/arrow-white.svg" alt="">
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-slide">
                        <div class="aximo-iconbox-wrap8 cornflower-bg">
                            <div class="aximo-iconbox-icon8">
                                <img src="assets/images/v6/icon-v-6-1.png" alt="">
                            </div>
                            <div class="aximo-iconbox-data8">
                                <h3>Residential Interior Design</h3>
                                <p>Tailored home design solutions that reflect the client's lifestyle, preferences, and functional needs.</p>
                                <a href="single-service.php">
                                    <img src="assets/images/v6/arrow-dark.svg" alt="">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-iconbox-wrap8 bg-light7">
                            <div class="aximo-iconbox-icon8">
                                <img src="assets/images/v6/icon-v-6-2.png" alt="">
                            </div>
                            <div class="aximo-iconbox-data8">
                                <h3>Commercial Interior Design</h3>
                                <p>Office design solutions focusing on functionality, color, productivity, and a professional aesthetic look.</p>
                                <a href="single-service.php">
                                    <img src="assets/images/v6/arrow-dark.svg" alt="">
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-iconbox-wrap8 green-bg2">
                            <div class="aximo-iconbox-icon8">
                                <img src="assets/images/v6/icon-v-6-3.png" alt="">
                            </div>
                            <div class="aximo-iconbox-data8 light">
                                <h3>Space Planning</h3>
                                <p>Space planning, furniture selection, color coordination, to create inviting and personalized interiors.</p>
                                <a href="single-service.php">
                                    <img src="assets/images/v6/arrow-white.svg" alt="">
                                </a>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="aximo-iconbox-slider-arrows">
                    <div class="swiper-button-prev"></div>
                    <div class="swiper-button-next"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End section -->

<div class="section aximo-section-padding5 position-relative">
    <div class="container">
        <div class="aximo-section-title playfair center max-width-xl">
            <h2>Explore our latest interior design project</h2>
        </div>
        <div class="row">
            <div class="col-md-6">
                <div class="aximo-project-thumb5 wow fadeInUpX" data-wow-delay="0.1s">
                    <img src="assets/images/v6/p_1.png" alt="">
                    <div class="aximo-marquee-two">
                        <div class="aximo-infinite two">
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="aximo-project-thumb5 wow fadeInUpX" data-wow-delay="0.2s">
                    <img src="assets/images/v6/p_2.png" alt="">
                    <div class="aximo-marquee-two">
                        <div class="aximo-infinite two">
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-8">
                <div class="aximo-project-thumb5 wow fadeInUpX" data-wow-delay="0.3s">
                    <img src="assets/images/v6/p_3.png" alt="">
                    <div class="aximo-marquee-two">
                        <div class="aximo-infinite two">
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="aximo-project-thumb5 wow fadeInUpX" data-wow-delay="0.4s">
                    <img src="assets/images/v6/p_4.png" alt="">
                    <div class="aximo-marquee-two">
                        <div class="aximo-infinite two">
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                            <a href="">Corporate Elegance <img src="assets/images/v6/next-white.svg" alt=""></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="aximo-p-shape">
        <img src="assets/images/v6/shapes2.png" alt="">
    </div>
</div>
<!-- End section -->

<div class="section bg-light7 aximo-section-padding5">
    <div class="container">
        <div class="aximo-section-title playfair center">
            <h2>Expressions of our satisfied customers</h2>
        </div>
        <div class="row">
            <div class="col-xl-4 col-md-6">
                <div class="aximo-testimonial-wrap5 wow fadeInUpX" data-wow-delay="0.1s">
                    <div class="aximo-testimonial-data5">
                        <ul>
                            <li><img src="assets/images/v6/rating.png" alt=""></li>
                            <li><img src="assets/images/v6/rating.png" alt=""></li>
                            <li><img src="assets/images/v6/rating.png" alt=""></li>
                            <li><img src="assets/images/v6/rating.png" alt=""></li>
                            <li><img src="assets/images/v6/rating.png" alt=""></li>
                        </ul>
                        <h3>Highly recommended!</h3>
                        <p>“I recently used their luxury tile flooring services and I was extremely impressed with the quality of their work and the professionalism of their team.”</p>
                        <h6>William Jack <span>Creative Director</span></h6>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-6">
                <div class="aximo-testimonial-wrap5 wow fadeInUpX" data-wow-delay="0.2s">
                    <div class="aximo-testimonial-data5">
                        <ul>
                            <li><img src="assets/images/v6/rating.png" alt=""></li>
                            <li><img src="assets/images/v6/rating.png" alt=""></li>
                            <li><img src="assets/images/v6/rating.png" alt=""></li>
                            <li><img src="assets/images/v6/rating.png" alt=""></li>
                            <li><img src="assets/images/v6/rating.png" alt=""></li>
                        </ul>
                        <h3>Amazing experience!</h3>
                        <p>“I spoke with them to decorate my new home and I am very happy that they did as promised. They made my dream home a reality! I am very satisfied."</p>
                        <h6>Mark Jones <span>Businessman</span></h6>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-md-6 offset-lg-0 offset-md-3">
                <div class="aximo-testimonial-wrap5 wow fadeInUpX" data-wow-delay="0.3s">
                    <div class="aximo-testimonial-data5">
                        <ul>
                            <li><img src="assets/images/v6/rating.png" alt=""></li>
                            <li><img src="assets/images/v6/rating.png" alt=""></li>
                            <li><img src="assets/images/v6/rating.png" alt=""></li>
                            <li><img src="assets/images/v6/rating.png" alt=""></li>
                            <li><img src="assets/images/v6/rating.png" alt=""></li>
                        </ul>
                        <h3>Fantastic service!</h3>
                        <p>“Professional service for New Yorker wall installation, flexibility in timelines, & great prices with wonderful results can't be found anywhere else.”</p>
                        <h6>Pitter Hoark <span>Teacher</span></h6>
                    </div>
                </div>
            </div>
        </div>
        <div class="aximo-bottom-center">
            <a class="aximo-default-btn green-btn pill" href="testimonial.php"><span>Explore All Reviews</span> </a>
        </div>
    </div>
</div>
<!-- End section -->

<div class="section aximo-section-padding3">
    <div class="container">
        <div class="aximo-section-title playfair">
            <div class="row">
                <div class="col-lg-8">
                    <h2>Check out our latest articles and news</h2>
                </div>
                <div class="col-lg-4 d-flex align-items-center">
                    <div class="aximo-title-btn">
                        <a class="aximo-default-btn green-btn pill" href="blog.php"><span>Explore All Blogs</span> </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-6">
                <div class="aximo-blog-wrap2 wow fadeInUpX" data-wow-delay="0.1s">
                    <div class="aximo-blog-thumb2">
                        <a href="single-blog.php">
                            <img src="assets/images/v6/blog-v6-1.png" alt="">
                        </a>
                    </div>
                    <div class="aximo-blog-content2">
                        <div class="aximo-blog-meta2">
                            <ul>
                                <li>Home Decoration</li>
                                <li>June 15, 2024</li>
                            </ul>
                        </div>
                        <a href="single-blog.php">
                            <h3>How to create a dramatic paint color for the home</h3>
                        </a>
                        <p>At the beginning of a home redesign, the client said she found herself "making much safer choices… </p>
                        <a class="aximo-blog-btn" href="single-blog.php">
                            <img src="assets/images/v6/next.svg" alt="">
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="aximo-blog-wrap2 wow fadeInUpX" data-wow-delay="0.2s">
                    <div class="aximo-blog-thumb2">
                        <a href="single-blog.php">
                            <img src="assets/images/v6/blog-v6-2.png" alt="">
                        </a>
                    </div>
                    <div class="aximo-blog-content2">
                        <div class="aximo-blog-meta2">
                            <ul>
                                <li>Office Interior </li>
                                <li>June 10, 2024</li>
                            </ul>
                        </div>
                        <a href="single-blog.php">
                            <h3>The smartest way to create an office in a small space</h3>
                        </a>
                        <p>Of course, having a dedicated home office with ample storage, room for supplies, and a proper desk setup...</p>
                        <a class="aximo-blog-btn" href="single-blog.php">
                            <img src="assets/images/v6/next.svg" alt="">
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End section -->

<!-- Footer  -->
<footer class="section dark-bg2 position-relative">
    <div class="container">
        <div class="aximo-footer-extra-top">
            <div class="aximo-section-title center playfair pb-0 light max-width-xl">
                <h2>Want to decorate your dream space with us?</h2>
            </div>
            <div class="aximo-footer-info-wrap">
                <a class="aximo-footer-info wow fadeInUpX" data-wow-delay="0.1s" href="mailto:pixcelsthemes@gmail.com">pixcelsthemes@gmail.com</a>
                <a class="aximo-footer-info wow fadeInUpX" data-wow-delay="0.2s" href="">+088-234-684900</a>
                <a class="aximo-footer-info wow fadeInUpX" data-wow-delay="0.3s" href="">Haward Street,10203 USA</a>
            </div>
        </div>
        <div class="aximo-footer-top6">
            <div class="row">
                <div class="col-xl-4 col-lg-12">
                    <div class="aximo-footer-textarea light-two">
                        <a href="">
                            <img src="assets/images/logo/logo-white.svg" alt="">
                        </a>
                        <p>We are a branding agency that digitally works to help companies grow. We have a successful track record of working with various organizations.</p>
                        <div class="aximo-copywright">
                            <p> &copy; Copyright 2024, All Rights Reserved by Pixcels Themes</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-md-4">
                    <div class="aximo-footer-menu extar-margin light-two">
                        <div class="aximo-footer-title light-two">
                            <p>Special Links</p>
                        </div>
                        <ul>
                            <li><a href="">About us</a></li>
                            <li><a href="">Our services</a></li>
                            <li><a href="">Portfolio</a></li>
                            <li><a href="">Blogs</a></li>
                            <li><a href="">Premium member</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-3 col-md-4">
                    <div class="aximo-footer-menu light-two">
                        <div class="aximo-footer-title light-two">
                            <p>Utility pages</p>
                        </div>
                        <ul>
                            <li><a href="">About us</a></li>
                            <li><a href="">Our services</a></li>
                            <li><a href="">Portfolio</a></li>
                            <li><a href="">Blogs</a></li>
                            <li><a href="">Premium member</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-2 col-md-4">
                    <div class="aximo-footer-title light-two">
                        <p>Socials Links</p>
                        <div class="aximo-social-icon5">
                            <ul>
                                <li>
                                    <a href="">
                                        <i class="icon-facebook"></i>
                                        Facebook
                                    </a>
                                </li>
                                <li>
                                    <a href="">
                                        <i class="icon-twitter"></i>
                                        Twitter
                                    </a>
                                </li>
                                <li>
                                    <a href="">
                                        <i class="icon-instagram"></i>
                                        Instagram
                                    </a>
                                </li>
                                <li>
                                    <a href="">
                                        <i class="icon-linkedin"></i>
                                        Linkedin
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>


    </div>
    <div class="aximo-footer-shapev6">
        <img src="assets/images/v6/shapes.png" alt="">
    </div>
</footer>

<?php include './partials/layouts/layoutBottom2.php' ?>