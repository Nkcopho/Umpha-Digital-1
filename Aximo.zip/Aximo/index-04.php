<?php include './partials/layouts/layoutTop3.php' ?>

    <header class="site-header site-header--menu-center aximo-header-section aximo-header4 bg-light4" id="sticky-menu">
        <div class="container">
            <nav class="navbar site-navbar">
                <!-- Brand Logo-->
                <div class="brand-logo">
                    <a href="index.php">
                        <img src="assets/images/logo/logo-dark.svg" alt="" class="light-version-logo">
                    </a>
                </div>
                <div class="menu-block-wrapper">
                    <div class="menu-overlay"></div>
                    <nav class="menu-block" id="append-menu-header">
                        <div class="mobile-menu-head">
                            <div class="go-back">
                                <i class="fa fa-angle-left"></i>
                            </div>
                            <div class="current-menu-title"></div>
                            <div class="mobile-menu-close">&times;</div>
                        </div>
                        <ul class="site-menu-main">
                            <li class="nav-item nav-item-has-children">
                                <a href="#" class="nav-link-item drop-trigger">Demo <i class="fas fa-angle-down"></i></a>
                                <ul class="sub-menu" id="submenu-1">
                                    <li class="sub-menu--item">
                                        <a href="index.php">
                                            <span class="menu-item-text">Design Agency</span>
                                        </a>
                                    </li>
                                    <li class="sub-menu--item">
                                        <a href="index-02.php">
                                            <span class="menu-item-text">Startup Agency</span>
                                        </a>
                                    </li>
                                    <li class="sub-menu--item">
                                        <a href="index-03.php">
                                            <span class="menu-item-text">SEO Agency</span>
                                        </a>
                                    </li>
                                    <li class="sub-menu--item">
                                        <a href="index-04.php">
                                            <span class="menu-item-text">Business Consultation</span>
                                        </a>
                                    </li>
                                    <li class="sub-menu--item">
                                        <a href="index-05.php">
                                            <span class="menu-item-text">Digital Marketing</span>
                                        </a>
                                    </li>
                                    <li class="sub-menu--item">
                                        <a href="index-06.php">
                                            <span class="menu-item-text">Interior Design Agency</span>
                                        </a>
                                    </li>
                                    <li class="sub-menu--item">
                                        <a href="index-07.php">
                                            <span class="menu-item-text">Advertising agency</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <a href="about-us.php" class="nav-link-item">About Us</a>
                            </li>
                            <li class="nav-item nav-item-has-children">
                                <a href="#" class="nav-link-item drop-trigger">Pages <i class="fas fa-angle-down"></i></a>
                                <ul class="sub-menu" id="submenu-2">
                                    <li class="sub-menu--item">
                                        <a href="about-us.php">
                                            <span class="menu-item-text">About Us</span>
                                        </a>
                                    </li>
                                    <li class="sub-menu--item">
                                        <a href="pricing.php">
                                            <span class="menu-item-text">Pricing</span>
                                        </a>
                                    </li>
                                    <li class="sub-menu--item nav-item-has-children">
                                        <a href="#" data-menu-get="h3" class="drop-trigger">blog <i class="fas fa-angle-down"></i></a>
                                        <ul class="sub-menu shape-none" id="submenu-3">
                                            <li class="sub-menu--item">
                                                <a href="blog.php">
                                                    <span class="menu-item-text">Our Blog</span>
                                                </a>
                                            </li>
                                            <li class="sub-menu--item">
                                                <a href="blog-grid.php">
                                                    <span class="menu-item-text">Blog grid</span>
                                                </a>
                                            </li>
                                            <li class="sub-menu--item">
                                                <a href="single-blog.php">
                                                    <span class="menu-item-text">blog details</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="sub-menu--item nav-item-has-children">
                                        <a href="#" data-menu-get="h3" class="drop-trigger">Service<i class="fas fa-angle-down"></i>
                                        </a>
                                        <ul class="sub-menu shape-none" id="submenu-4">
                                            <li class="sub-menu--item">
                                                <a href="service.php">
                                                    <span class="menu-item-text">service</span>
                                                </a>
                                            </li>
                                            <li class="sub-menu--item">
                                                <a href="single-service.php">
                                                    <span class="menu-item-text">service details</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="sub-menu--item nav-item-has-children">
                                        <a href="#" data-menu-get="h3" class="drop-trigger">Team<i class="fas fa-angle-down"></i>
                                        </a>
                                        <ul class="sub-menu shape-none" id="submenu-5">
                                            <li class="sub-menu--item">
                                                <a href="team.php">
                                                    <span class="menu-item-text">team</span>
                                                </a>
                                            </li>
                                            <li class="sub-menu--item">
                                                <a href="single-team.php">
                                                    <span class="menu-item-text">team details</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="sub-menu--item nav-item-has-children">
                                        <a href="#" data-menu-get="h3" class="drop-trigger">Portfolio<i class="fas fa-angle-down"></i>
                                        </a>
                                        <ul class="sub-menu shape-none" id="submenu-6">
                                            <li class="sub-menu--item">
                                                <a href="portfolio-02.php">
                                                    <span class="menu-item-text">Portfolio One Column</span>
                                                </a>
                                            </li>
                                            <li class="sub-menu--item">
                                                <a href="portfolio-01.php">
                                                    <span class="menu-item-text">Portfolio Two Column</span>
                                                </a>
                                            </li>
                                            <li class="sub-menu--item">
                                                <a href="single-portfolio.php">
                                                    <span class="menu-item-text">Single Portfolio</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="sub-menu--item nav-item-has-children">
                                        <a href="#" data-menu-get="h3" class="drop-trigger">Utility<i class="fas fa-angle-down"></i>
                                        </a>
                                        <ul class="sub-menu shape-none" id="submenu-7">
                                            <li class="sub-menu--item">
                                                <a href="faq.php">
                                                    <span class="menu-item-text">faq</span>
                                                </a>
                                            </li>
                                            <li class="sub-menu--item">
                                                <a href="errors-404.php">
                                                    <span class="menu-item-text">Error 404</span>
                                                </a>
                                            </li>
                                            <li class="sub-menu--item">
                                                <a href="testimonial.php">
                                                    <span class="menu-item-text">testimonial</span>
                                                </a>
                                            </li>
                                            <li class="sub-menu--item">
                                                <a href="coming-soon.php">
                                                    <span class="menu-item-text">Coming Soon</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="sub-menu--item nav-item-has-children">
                                        <a href="#" data-menu-get="h3" class="drop-trigger">Account<i class="fas fa-angle-down"></i>
                                        </a>
                                        <ul class="sub-menu shape-none" id="submenu-8">
                                            <li class="sub-menu--item">
                                                <a href="sign-up.php">
                                                    <span class="menu-item-text">sign up</span>
                                                </a>
                                            </li>
                                            <li class="sub-menu--item">
                                                <a href="sign-in.php">
                                                    <span class="menu-item-text">sign in</span>
                                                </a>
                                            </li>
                                            <li class="sub-menu--item">
                                                <a href="reset-password.php">
                                                    <span class="menu-item-text">reset password</span>
                                                </a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item nav-item-has-children">
                                <a href="#" class="nav-link-item drop-trigger">Blog <i class="fas fa-angle-down"></i></a>
                                <ul class="sub-menu" id="submenu-9">
                                    <li class="sub-menu--item">
                                        <a href="blog.php">
                                            <span class="menu-item-text">blog</span>
                                        </a>
                                    </li>
                                    <li class="sub-menu--item">
                                        <a href="blog-grid.php">
                                            <span class="menu-item-text">Blog grid</span>
                                        </a>
                                    </li>
                                    <li class="sub-menu--item">
                                        <a href="single-blog.php">
                                            <span class="menu-item-text">blog Details</span>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <a href="contact-us.php" class="nav-link-item">Contact Us</a>
                            </li>
                        </ul>
                    </nav>
                </div>

                <div class="header-btn header-btn-l1 ms-auto d-none d-xs-inline-flex">
                    <a class="aximo-default-btn aximo-header-btn outline-btn pill barger-menu " href="">
                        <img src="assets/images/v4/barger-menu.svg" alt="">
                        Menu
                    </a>
                </div>
                <!-- mobile menu trigger -->
                <div class="mobile-menu-trigger">
                    <span></span>
                </div>
                <!--/.Mobile Menu Hamburger Ends-->
            </nav>
        </div>
    </header>
    <!--End landex-header-section -->

    <div class="aximo-sidemenu-wraper">
        <div class="aximo-sidemenu-column">
            <div class="aximo-sidemenu-body">
                <div class="aximo-sidemenu-logo">
                    <a href=""><img src="assets/images/logo/logo-white.svg" alt=""></a>
                </div>
                <p>We're dedicated to helping business grow and succeed. With years of industry experience and a passion for problem-solving, we offer top-level consulting service tailored to your unique needs.</p>
                <div class="aximo-sidemenu-thumb">
                    <img src="assets/images/v4/instagram-thumb3.png" alt="">
                </div>
                <div class="aximo-info-wrap">
                    <div class="aximo-info">
                        <ul>
                            <li>Give us a call:</li>
                            <li><a href="">(123) 456-7890</a></li>
                        </ul>
                    </div>
                    <div class="aximo-info">
                        <ul>
                            <li>Send us an email:</li>
                            <li><a href="mailto:pixcelsthemes@gmail.com">pixcelsthemes@gmail.com</a></li>
                        </ul>
                    </div>
                </div>
                <div class="aximo-social-icon aximo-social-icon3">
                    <ul>
                        <li>
                            <a href="">
                                <i class="icon-twitter"></i>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <i class="icon-facebook"></i>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <i class="icon-instagram"></i>
                            </a>
                        </li>
                        <li>
                            <a href="">
                                <i class="icon-linkedin"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="aximo-copywright4 light">
                    <p> © Copyright 2024, All Rights Reserved by Pixcels Themes</p>
                </div>
            </div>
            <span class="aximo-sidemenu-close">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                    <path d="M6 18L18 6M6 6L18 18" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path>
                </svg>
            </span>
        </div>
        <div class="offcanvas-overlay"></div>

    </div>

    <div class="offcanves-menu"></div>

    <div class="aximo-all-section bg-light4">
        <div class="aximo-hero-section4" style="background-image: url(assets/images/v4/hero-bg.png)">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="aximo-hero-content4">
                            <p><span>Your trusted business consultants</span></p>
                            <h1>
                                Transforming your ideas into
                                <span class="aximo-hero-shape-title">
                                    experiences
                                    <span class="aximo-hero-round-shape">
                                        <img src="assets/images/v4/round-shape.png" alt="">
                                    </span>
                                </span>
                            </h1>
                            <p>We're dedicated to helping businesses grow and succeed. With years of industry experience and a passion for problem-solving, we offer top-level consulting services tailored to your unique needs.</p>
                            <div class="aximo-hero-btn-wrap">
                                <a class="aximo-default-btn pill blue-btn wow fadeInUpX" data-wow-delay="0.1s" href="contact-us.php">
                                    Schedule a meeting
                                </a>
                                <a class="aximo-default-btn aximo-default-btn-outline pill outline-white wow fadeInUpX" data-wow-delay="0.2s" href="portfolio-01.php">
                                    <span class="aximo-label-up">View all projects</span>
                                    <span class="aximo-label-up">View all projects</span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 d-flex align-items-end justify-content-center">
                        <div class="aximo-hero-video-section">
                            <a class="aximo-video-popup3 video-init" href="https://www.youtube.com/watch?v=7e90gBu4pas">
                                <img class="aximo-video-circle" src="assets/images/v4/circle-play.png" alt="">
                                <img class="aximo-video-icon" src="assets/images/v4/play-icon.svg" alt="">
                            </a>
                        </div>
                        <!-- End section -->
                    </div>
                </div>
            </div>
        </div>
        <!-- End sction -->

        <div class="aximo-content-section position-relative overflow-hidden">
            <div class="container">
                <div class="aximo-section-title arimo-font center full-width p-0">
                    <span class="aximo-subtitle">Our mission & vision</span>
                    <h2>Our mission is to help businesses thrive a fast-paced <img src="assets/images/v4/text-thumb1.png" alt=""> competitive world by providing expert guidance <img src="assets/images/v4/text-thumb2.png" alt=""> & we're here to provide it.</h2>
                </div>
            </div>
            <div class="aximo-v4-shape1">
                <img src="assets/images/v4/shape1.png" alt="">
            </div>
        </div>
        <!-- End sction -->

        <div class="aximo-brandlogo-section2 extra-side-margin">
            <div class="aximo-brandlogo-title2">
                <p>We help hundreds of companies to grow</p>
            </div>
            <div class="swiper aximo-auto-slider">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_1.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_2.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_3.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_4.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_5.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_6.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_7.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_1.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_2.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_3.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_4.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_5.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_6.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_7.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_1.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_2.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_3.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_4.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_5.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_6.png" alt="">
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-brandlogo-item">
                            <img src="assets/images/v4/b_7.png" alt="">
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <!-- end section -->

        <div class="section aximo-section-padding3 position-relative">
            <div class="container">
                <div class="aximo-section-title arimo-font">
                    <div class="row">
                        <div class="col-lg-7">
                            <span class="aximo-subtitle">Our amazing services</span>
                            <h2>We provide various essential services</h2>
                        </div>
                        <div class="col-lg-5 d-flex align-items-end justify-content-end">
                            <div class="aximo-title-btn">
                                <a class="aximo-default-btn pill blue-btn" href="service.php">
                                    View all services
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-4 col-lg-6">
                        <div class="aximo-iconbox-wrap4 wow fadeInUpX" data-wow-delay="0s">
                            <div class="aximo-iconbox-icon4">
                                <i class="icon-idea-bulb"></i>
                            </div>
                            <div class="aximo-iconbox-data4">
                                <h3>Strategic Planning</h3>
                                <p>Actionable strategies that align with your business objectives, ensuring you're on the path to success.</p>
                                <a class="aximo-icon" href="single-service.php">
                                    <svg width="26" height="20" viewBox="0 0 26 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M15.5 1.25L24.25 10M24.25 10L15.5 18.75M24.25 10L1.75 10" stroke="#191931" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6">
                        <div class="aximo-iconbox-wrap4 wow fadeInUpX" data-wow-delay="0.1s">
                            <div class="aximo-iconbox-icon4">
                                <i class="icon-project-management"></i>
                            </div>
                            <div class="aximo-iconbox-data4">
                                <h3>Operational Excellence</h3>
                                <p>We optimize your processes & work improve efficiency, and reduce costs to enhance overall performance.</p>
                                <a class="aximo-icon" href="single-service.php">
                                    <svg width="26" height="20" viewBox="0 0 26 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M15.5 1.25L24.25 10M24.25 10L15.5 18.75M24.25 10L1.75 10" stroke="#191931" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6">
                        <div class="aximo-iconbox-wrap4 wow fadeInUpX" data-wow-delay="0.2s">
                            <div class="aximo-iconbox-icon4">
                                <i class="icon-start-up"></i>
                            </div>
                            <div class="aximo-iconbox-data4">
                                <h3>Financial Advisory</h3>
                                <p>Our experts provide financial guide, help manage investments, & risk to ensure your financial health.</p>
                                <a class="aximo-icon" href="single-service.php">
                                    <svg width="26" height="20" viewBox="0 0 26 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M15.5 1.25L24.25 10M24.25 10L15.5 18.75M24.25 10L1.75 10" stroke="#191931" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6">
                        <div class="aximo-iconbox-wrap4 wow fadeInUpX" data-wow-delay="0.3s">
                            <div class="aximo-iconbox-icon4">
                                <i class="icon-database"></i>
                            </div>
                            <div class="aximo-iconbox-data4">
                                <h3>Technology Solutions</h3>
                                <p>We offer IT consulting to guide new technology adoption for enhance all cybersecurity for your business.</p>
                                <a class="aximo-icon" href="single-service.php">
                                    <svg width="26" height="20" viewBox="0 0 26 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M15.5 1.25L24.25 10M24.25 10L15.5 18.75M24.25 10L1.75 10" stroke="#191931" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6">
                        <div class="aximo-iconbox-wrap4 wow fadeInUpX" data-wow-delay="0.4s">
                            <div class="aximo-iconbox-icon4">
                                <i class="icon-data-analysis-1"></i>
                            </div>
                            <div class="aximo-iconbox-data4">
                                <h3>Marketing and Sales</h3>
                                <p>We help you develop effective and boost brand visibility to connect with your target audience.</p>
                                <a class="aximo-icon" href="single-service.php">
                                    <svg width="26" height="20" viewBox="0 0 26 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M15.5 1.25L24.25 10M24.25 10L15.5 18.75M24.25 10L1.75 10" stroke="#191931" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6">
                        <div class="aximo-iconbox-wrap4 wow fadeInUpX" data-wow-delay="0.5s">
                            <div class="aximo-iconbox-icon4">
                                <i class="icon-client-support"></i>
                            </div>
                            <div class="aximo-iconbox-data4">
                                <h3>Specialized Expertise</h3>
                                <p>With industry-specific knowledge, we provide tailored solutions for all sectors like healthcare, finance.</p>
                                <a class="aximo-icon" href="single-service.php">
                                    <svg width="26" height="20" viewBox="0 0 26 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M15.5 1.25L24.25 10M24.25 10L15.5 18.75M24.25 10L1.75 10" stroke="#191931" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End section -->

        <div class="section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-5">
                        <div class="aximo-content-thumb border-radius wow fadeInLeft" data-wow-delay=".1s">
                            <img src="assets/images/v4/thumb1.png" alt="">
                            <div class="aximo-thumb-shape4">
                                <img src="assets/images/v4/shape2.png" alt="">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="aximo-default-content arimo-font m-left-gap">
                            <span class="aximo-subtitle">Why choose us</span>
                            <h2>We help companies achieve their goals</h2>
                            <p>In today's complex and rapidly changing business environment, we help businesses adapt, grow & succeed. Our expertise, objectivity, and ability to provide customized solutions.</p>
                            <p> <strong>Industry Expertise:</strong> Our team of seasoned consultants brings wealth of knowledge and experience across various industries. </p>
                            <p> <strong>Results-Driven Approach:</strong> Our proven methodologies and data-driven strategies ensure that your business reaches. </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End section -->

        <div class="aximo-numberbox-section">
            <div class="container">
                <div class="row">
                    <div class="col-xl-4 col-lg-6">
                        <div class="aximo-numberbox-wrap">
                            <div class="aximo-numberbox-number">
                                1
                            </div>
                            <div class="aximo-numberbox-data">
                                <p><span>Initial Contact</span></p>
                                <p>Contact us & we’ll listen carefully to understand your unique needs & goals.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6">
                        <div class="aximo-numberbox-wrap">
                            <div class="aximo-numberbox-number">
                                2
                            </div>
                            <div class="aximo-numberbox-data">
                                <p><span>Solutions & Collaboration</span></p>
                                <p>We become your partners in progress, collaborating to implement solutions.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 col-lg-6">
                        <div class="aximo-numberbox-wrap">
                            <div class="aximo-numberbox-number">
                                3
                            </div>
                            <div class="aximo-numberbox-data">
                                <p><span>Monitoring & Results</span></p>
                                <p>We continuously monitoring and leads to your business achieving its goals.</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End section -->

        <div class="aximo-project-section aximo-section-padding extra-side-margin">
            <div class="container">
                <div class="aximo-section-title center light arimo-font">
                    <span class="aximo-subtitle">Our stunning creation</span>
                    <h2>
                        Our dedication shines through our work
                    </h2>
                </div>
            </div>
            <div class="swiper aximo-project-slider2 wow fadeInUpX" data-wow-delay="0.1s">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project1.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Market Expansion Blueprint</h3>
                                </a>
                                <p>Develop a comprehensive strategy to expand your market reach, identify new opportunities, and grow</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project2.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Financial Health Check</h3>
                                </a>
                                <p>A thorough financial analysis to assess the financial stability of your business and secure your future.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project3.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Strategic Growth Accelerator</h3>
                                </a>
                                <p>Develop a growth-focused strategy, including market expansion, product development.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project1.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Market Expansion Blueprint</h3>
                                </a>
                                <p>Develop a comprehensive strategy to expand your market reach, identify new opportunities, and grow</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project2.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Financial Health Check</h3>
                                </a>
                                <p>A thorough financial analysis to assess the financial stability of your business and secure your future.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project3.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Strategic Growth Accelerator</h3>
                                </a>
                                <p>Develop a growth-focused strategy, including market expansion, product development.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project1.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Market Expansion Blueprint</h3>
                                </a>
                                <p>Develop a comprehensive strategy to expand your market reach, identify new opportunities, and grow</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project2.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Financial Health Check</h3>
                                </a>
                                <p>A thorough financial analysis to assess the financial stability of your business and secure your future.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project3.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Strategic Growth Accelerator</h3>
                                </a>
                                <p>Develop a growth-focused strategy, including market expansion, product development.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project1.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Market Expansion Blueprint</h3>
                                </a>
                                <p>Develop a comprehensive strategy to expand your market reach, identify new opportunities, and grow</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project2.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Financial Health Check</h3>
                                </a>
                                <p>A thorough financial analysis to assess the financial stability of your business and secure your future.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project3.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Strategic Growth Accelerator</h3>
                                </a>
                                <p>Develop a growth-focused strategy, including market expansion, product development.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project1.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Market Expansion Blueprint</h3>
                                </a>
                                <p>Develop a comprehensive strategy to expand your market reach, identify new opportunities, and grow</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project2.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Financial Health Check</h3>
                                </a>
                                <p>A thorough financial analysis to assess the financial stability of your business and secure your future.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project3.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Strategic Growth Accelerator</h3>
                                </a>
                                <p>Develop a growth-focused strategy, including market expansion, product development.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project1.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Market Expansion Blueprint</h3>
                                </a>
                                <p>Develop a comprehensive strategy to expand your market reach, identify new opportunities, and grow</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project2.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Financial Health Check</h3>
                                </a>
                                <p>A thorough financial analysis to assess the financial stability of your business and secure your future.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project3.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Strategic Growth Accelerator</h3>
                                </a>
                                <p>Develop a growth-focused strategy, including market expansion, product development.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project1.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Market Expansion Blueprint</h3>
                                </a>
                                <p>Develop a comprehensive strategy to expand your market reach, identify new opportunities, and grow</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project2.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Financial Health Check</h3>
                                </a>
                                <p>A thorough financial analysis to assess the financial stability of your business and secure your future.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project3.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Strategic Growth Accelerator</h3>
                                </a>
                                <p>Develop a growth-focused strategy, including market expansion, product development.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project1.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Market Expansion Blueprint</h3>
                                </a>
                                <p>Develop a comprehensive strategy to expand your market reach, identify new opportunities, and grow</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project2.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Financial Health Check</h3>
                                </a>
                                <p>A thorough financial analysis to assess the financial stability of your business and secure your future.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project3.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Strategic Growth Accelerator</h3>
                                </a>
                                <p>Develop a growth-focused strategy, including market expansion, product development.</p>
                            </div>
                        </div>
                    </div>

                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project1.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Market Expansion Blueprint</h3>
                                </a>
                                <p>Develop a comprehensive strategy to expand your market reach, identify new opportunities, and grow</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project2.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Financial Health Check</h3>
                                </a>
                                <p>A thorough financial analysis to assess the financial stability of your business and secure your future.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project3.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Strategic Growth Accelerator</h3>
                                </a>
                                <p>Develop a growth-focused strategy, including market expansion, product development.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project1.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Market Expansion Blueprint</h3>
                                </a>
                                <p>Develop a comprehensive strategy to expand your market reach, identify new opportunities, and grow</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project2.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Financial Health Check</h3>
                                </a>
                                <p>A thorough financial analysis to assess the financial stability of your business and secure your future.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project3.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Strategic Growth Accelerator</h3>
                                </a>
                                <p>Develop a growth-focused strategy, including market expansion, product development.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project1.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Market Expansion Blueprint</h3>
                                </a>
                                <p>Develop a comprehensive strategy to expand your market reach, identify new opportunities, and grow</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project2.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Financial Health Check</h3>
                                </a>
                                <p>A thorough financial analysis to assess the financial stability of your business and secure your future.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project3.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Strategic Growth Accelerator</h3>
                                </a>
                                <p>Develop a growth-focused strategy, including market expansion, product development.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project1.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Market Expansion Blueprint</h3>
                                </a>
                                <p>Develop a comprehensive strategy to expand your market reach, identify new opportunities, and grow</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project2.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Financial Health Check</h3>
                                </a>
                                <p>A thorough financial analysis to assess the financial stability of your business and secure your future.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project3.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Strategic Growth Accelerator</h3>
                                </a>
                                <p>Develop a growth-focused strategy, including market expansion, product development.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project1.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Market Expansion Blueprint</h3>
                                </a>
                                <p>Develop a comprehensive strategy to expand your market reach, identify new opportunities, and grow</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project2.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Financial Health Check</h3>
                                </a>
                                <p>A thorough financial analysis to assess the financial stability of your business and secure your future.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project3.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Strategic Growth Accelerator</h3>
                                </a>
                                <p>Develop a growth-focused strategy, including market expansion, product development.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project1.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Market Expansion Blueprint</h3>
                                </a>
                                <p>Develop a comprehensive strategy to expand your market reach, identify new opportunities, and grow</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project2.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Financial Health Check</h3>
                                </a>
                                <p>A thorough financial analysis to assess the financial stability of your business and secure your future.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project3.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Strategic Growth Accelerator</h3>
                                </a>
                                <p>Develop a growth-focused strategy, including market expansion, product development.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project1.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Market Expansion Blueprint</h3>
                                </a>
                                <p>Develop a comprehensive strategy to expand your market reach, identify new opportunities, and grow</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project2.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Financial Health Check</h3>
                                </a>
                                <p>A thorough financial analysis to assess the financial stability of your business and secure your future.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project3.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Strategic Growth Accelerator</h3>
                                </a>
                                <p>Develop a growth-focused strategy, including market expansion, product development.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project1.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Market Expansion Blueprint</h3>
                                </a>
                                <p>Develop a comprehensive strategy to expand your market reach, identify new opportunities, and grow</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project2.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Financial Health Check</h3>
                                </a>
                                <p>A thorough financial analysis to assess the financial stability of your business and secure your future.</p>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-project-wrap2">
                            <div class="aximo-project-thumb2">
                                <img src="assets/images/v4/project3.png" alt="">
                                <a class="aximo-project-icon2" href="single-portfolio.php">
                                    <img src="assets/images/v4/link.svg" alt="">
                                </a>
                            </div>
                            <div class="aximo-project-data2">
                                <a href="single-portfolio.php">
                                    <h3>Strategic Growth Accelerator</h3>
                                </a>
                                <p>Develop a growth-focused strategy, including market expansion, product development.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="swiper-scrollbar"></div>
            </div>
        </div>
        <!-- End section -->

        <div class="section aximo-section-padding5 position-relative">
            <div class="container">
                <div id="aximo-counter"></div>
                <div class="aximo-section-title arimo-font">
                    <div class="row">
                        <div class="col-lg-7">
                            <span class="aximo-subtitle">Client success stories</span>
                            <h2>Don't just trust us, hear from others</h2>
                        </div>
                        <div class="col-lg-5 d-flex align-items-end justify-content-end">
                            <div class="aximo-title-btn">
                                <a class="aximo-default-btn pill blue-btn" href="service.php">
                                    View all services
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4">
                        <div class="aximo-counter-wrap4 wow fadeInUpX" data-wow-delay="0.1s">
                            <div class="aximo-counter-data4">
                                <h2><span data-percentage="80" class="aximo-counter"></span>k+</h2>
                                <p>Years of experience</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="aximo-testimonial-wrap aximo-testimonial-wrap3 wow fadeInUpX" data-wow-delay="0.2s">
                            <div class="aximo-testimonial-quote">
                                <img src="assets/images/v4/quote.png" alt="">
                            </div>
                            <div class="aximo-testimonial-data">
                                <p>Excellent customer service and I was really impressed and happy with my purchase especially as it was a last minute order which got to me in time, and when it arrived I was very happy with the design and size and so was the recipient.</p>
                            </div>
                            <div class="aximo-testimonial-author">
                                <div class="aximo-testimonial-author-thumb">
                                    <img src="assets/images/v1/t_thumb1.png" alt="">
                                </div>
                                <div class="aximo-testimonial-author-data">
                                    <span>William Jack </span>
                                    <p>CEO & Founder @XYZ</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 order-lg-2">
                        <div class="aximo-counter-wrap4 wow fadeInUpX" data-wow-delay="0.3s">
                            <div class="aximo-counter-data4">
                                <h2><span data-percentage="200" class="aximo-counter"></span>+</h2>
                                <p>Successfully finished projects</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-8">
                        <div class="aximo-testimonial-wrap aximo-testimonial-wrap3 wow fadeInUpX" data-wow-delay="0.4s">
                            <div class="aximo-testimonial-quote">
                                <img src="assets/images/v4/quote.png" alt="">
                            </div>
                            <div class="aximo-testimonial-data">
                                <p>"Working with Pixcels Themes has been a game-changer for our company. Their tailored solutions & hands-on approach have not only boosted our efficiency but have also opened up new avenues for growth. They are an invaluable partner in our journey to success."</p>
                            </div>
                            <div class="aximo-testimonial-author">
                                <div class="aximo-testimonial-author-thumb">
                                    <img src="assets/images/v1/t_thumb2.png" alt="">
                                </div>
                                <div class="aximo-testimonial-author-data">
                                    <span>Andrew Smith </span>
                                    <p>Businessman</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="aximo-v4-shape2">
                <img src="assets/images/v4/shape4.png" alt="">
            </div>
        </div>
        <!-- End section -->

        <div class="aximo-blog-section aximo-section-padding position-relative">
            <div class="container">
                <div class="aximo-section-title center arimo-font">
                    <span class="aximo-subtitle">Read our blog</span>
                    <h2>
                        We're passionate about knowledge sharing
                    </h2>
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="aximo-blog-wrap wow fadeInUpX" data-wow-delay="0.1s">
                            <div class="aximo-blog-thumb">
                                <a href="single-blog.php">
                                    <img src="assets/images/blog/blog1.png" alt="">
                                </a>
                            </div>
                            <div class="aximo-blog-content">
                                <div class="aximo-blog-meta">
                                    <ul>
                                        <li><a href="">Marketing</a></li>
                                        <li>June 18, 2024</li>
                                    </ul>
                                </div>
                                <a href="single-blog.php">
                                    <h3>How does business intelligence help companies change strategy?</h3>
                                </a>
                                <a class="aximo-blog-btn" href="single-blog.php">
                                    Read more
                                    <svg width="20" height="16" viewBox="0 0 20 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 1L19 8M19 8L12 15M19 8L1 8" stroke="#191931" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="aximo-blog-wrap wow fadeInUpX" data-wow-delay="0.2s">
                            <div class="aximo-blog-thumb">
                                <a href="single-blog.php">
                                    <img src="assets/images/blog/blog2.png" alt="">
                                </a>
                            </div>
                            <div class="aximo-blog-content">
                                <div class="aximo-blog-meta">
                                    <ul>
                                        <li><a href="">Technology</a></li>
                                        <li>June 18, 2024</li>
                                    </ul>
                                </div>
                                <a href="single-blog.php">
                                    <h3>Maximizing profits - the small business guide to Artificial Intelligence</h3>
                                </a>
                                <a class="aximo-blog-btn" href="single-blog.php">
                                    Read more
                                    <svg width="20" height="16" viewBox="0 0 20 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M12 1L19 8M19 8L12 15M19 8L1 8" stroke="#191931" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="aximo-v4-shape3">
                <img src="assets/images/v4/shape5.png" alt="">
            </div>
        </div>
        <!-- End section -->

        <div class="aximo-instagram-section">
            <div class="swiper aximo-instagram-slider">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <div class="aximo-instagram-thumb">
                            <img src="assets/images/v4/instagram-thumb1.png" alt="">
                            <div class="aximo-instagram-data">
                                <a href="https://www.instagram.com/"><i class="icon-instagram"></i></a>
                                <h3><a href="https://pixcelsthemes.com/" target="_blank">@Pixcels Themes</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-instagram-thumb">
                            <img src="assets/images/v4/instagram-thumb2.png" alt="">
                            <div class="aximo-instagram-data">
                                <a href="https://www.instagram.com/"><i class="icon-instagram"></i></a>
                                <h3><a href="https://pixcelsthemes.com/" target="_blank">@Pixcels Themes</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-instagram-thumb">
                            <img src="assets/images/v4/instagram-thumb3.png" alt="">
                            <div class="aximo-instagram-data">
                                <a href="https://www.instagram.com/"><i class="icon-instagram"></i></a>
                                <h3><a href="https://pixcelsthemes.com/" target="_blank">@Pixcels Themes</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-instagram-thumb">
                            <img src="assets/images/v4/instagram-thumb4.png" alt="">
                            <div class="aximo-instagram-data">
                                <a href="https://www.instagram.com/"><i class="icon-instagram"></i></a>
                                <h3><a href="https://pixcelsthemes.com/" target="_blank">@Pixcels Themes</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-instagram-thumb">
                            <img src="assets/images/v4/instagram-thumb5.png" alt="">
                            <div class="aximo-instagram-data">
                                <a href="https://www.instagram.com/"><i class="icon-instagram"></i></a>
                                <h3><a href="https://pixcelsthemes.com/" target="_blank">@Pixcels Themes</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-instagram-thumb">
                            <img src="assets/images/v4/instagram-thumb1.png" alt="">
                            <div class="aximo-instagram-data">
                                <a href="https://www.instagram.com/"><i class="icon-instagram"></i></a>
                                <h3><a href="https://pixcelsthemes.com/" target="_blank">@Pixcels Themes</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-instagram-thumb">
                            <img src="assets/images/v4/instagram-thumb2.png" alt="">
                            <div class="aximo-instagram-data">
                                <a href="https://www.instagram.com/"><i class="icon-instagram"></i></a>
                                <h3><a href="https://pixcelsthemes.com/" target="_blank">@Pixcels Themes</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-instagram-thumb">
                            <img src="assets/images/v4/instagram-thumb3.png" alt="">
                            <div class="aximo-instagram-data">
                                <a href="https://www.instagram.com/"><i class="icon-instagram"></i></a>
                                <h3><a href="https://pixcelsthemes.com/" target="_blank">@Pixcels Themes</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-instagram-thumb">
                            <img src="assets/images/v4/instagram-thumb4.png" alt="">
                            <div class="aximo-instagram-data">
                                <a href="https://www.instagram.com/"><i class="icon-instagram"></i></a>
                                <h3><a href="https://pixcelsthemes.com/" target="_blank">@Pixcels Themes</a></h3>
                            </div>
                        </div>
                    </div>
                    <div class="swiper-slide">
                        <div class="aximo-instagram-thumb">
                            <img src="assets/images/v4/instagram-thumb5.png" alt="">
                            <div class="aximo-instagram-data">
                                <a href="https://www.instagram.com/"><i class="icon-instagram"></i></a>
                                <h3><a href="https://pixcelsthemes.com/" target="_blank">@Pixcels Themes</a></h3>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- End all -->

    <!-- Footer  -->
    <footer class="aximo-footer-section4">
        <div class="aximo-subscription-wrap extra-side-margin">
            <div class="container">
                <div class="aximo-subscription2">
                    <form action="#">
                        <input type="email" placeholder="Email Address">
                        <button id="aximo-subscription-btn2" type="submit">Subscribe now</button>
                    </form>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="aximo-footer-top4">
                <div class="row">
                    <div class="col-xl-4 col-lg-12">
                        <div class="aximo-footer-textarea light-one">
                            <a href="">
                                <img src="assets/images/logo/logo-white.svg" alt="">
                            </a>
                            <p>We are a branding agency that digitally works to help companies grow. We have a successful track record of working with various organizations.</p>
                            <div class="aximo-social-icon aximo-social-icon3">
                                <ul>
                                    <li>
                                        <a href="https://twitter.com/" target="_blank">
                                            <i class="icon-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://facebook.com/" target="_blank">
                                            <i class="icon-facebook"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.instagram.com/" target="_blank">
                                            <i class="icon-instagram"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="https://www.linkedin.com/" target="_blank">
                                            <i class="icon-linkedin"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-4">
                        <div class="aximo-footer-menu extar-margin light-one">
                            <div class="aximo-footer-title light-one">
                                <p>Special Links</p>
                            </div>
                            <ul>
                                <li><a href="">About us</a></li>
                                <li><a href="">Our services</a></li>
                                <li><a href="">Portfolio</a></li>
                                <li><a href="">Blogs</a></li>
                                <li><a href="">Premium member</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-2 col-md-4">
                        <div class="aximo-footer-menu light-one">
                            <div class="aximo-footer-title light-one">
                                <p>Utility pages</p>
                            </div>
                            <ul>
                                <li><a href="">About us</a></li>
                                <li><a href="">Our services</a></li>
                                <li><a href="">Portfolio</a></li>
                                <li><a href="">Blogs</a></li>
                                <li><a href="">Premium member</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-xl-3 col-md-4">
                        <div class="aximo-footer-menu light-one m-0">
                            <div class="aximo-footer-title light-one">
                                <p>Contact us</p>
                            </div>
                            <div class="aximo-contact-info2">
                                <ul>
                                    <li>
                                        <a href="">
                                            <i class="icon-phone"></i>
                                            +088-234-6849
                                        </a>
                                    </li>
                                    <li>
                                        <a href="">
                                            <i class="icon-message"></i>
                                            example@gmail.com
                                        </a>
                                    </li>
                                    <li>
                                        <a href="">
                                            <i class="icon-map"></i>
                                            Haward Street,10203 USA
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="aximo-footer-bottom four">
                <div class="aximo-copywright four text-center">
                    <p> &copy; Copyright 2024, All Rights Reserved by Pixcels Themes</p>
                </div>
            </div>

        </div>
    </footer>

    <?php include './partials/layouts/layoutBottom2.php' ?>