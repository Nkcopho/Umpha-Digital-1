<header class="site-header aximo-header-section aximo-header1 dark-bg" id="sticky-menu">
    <div class="container">
        <nav class="navbar site-navbar">
            <!-- Brand Logo-->
            <div class="brand-logo">
                <a href="index.php">
                    <img src="assets/images/logo/logo-white.svg" alt="" class="light-version-logo">
                </a>
            </div>
            <div class="menu-block-wrapper">
                <div class="menu-overlay"></div>
                <nav class="menu-block" id="append-menu-header">
                    <div class="mobile-menu-head">
                        <div class="go-back">
                            <i class="fa fa-angle-left"></i>
                        </div>
                        <div class="current-menu-title"></div>
                        <div class="mobile-menu-close">&times;</div>
                    </div>
                    <ul class="site-menu-main">
                        <li class="nav-item nav-item-has-children">
                            <a href="#" class="nav-link-item drop-trigger">Demo <i class="fas fa-angle-down"></i></a>
                            <ul class="sub-menu" id="submenu-1">
                                <li class="sub-menu--item">
                                    <a href="index.php">
                                        <span class="menu-item-text">Design Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-02.php">
                                        <span class="menu-item-text">Startup Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-03.php">
                                        <span class="menu-item-text">SEO Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-04.php">
                                        <span class="menu-item-text">Business Consultation</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-05.php">
                                        <span class="menu-item-text">Digital Marketing</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-06.php">
                                        <span class="menu-item-text">Interior Design Agency</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="index-07.php">
                                        <span class="menu-item-text">Advertising agency</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a href="about-us.php" class="nav-link-item">About Us</a>
                        </li>
                        <li class="nav-item nav-item-has-children">
                            <a href="#" class="nav-link-item drop-trigger">Pages <i class="fas fa-angle-down"></i></a>
                            <ul class="sub-menu" id="submenu-2">
                                <li class="sub-menu--item">
                                    <a href="about-us.php">
                                        <span class="menu-item-text">About Us</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="pricing.php">
                                        <span class="menu-item-text">Pricing</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">blog <i class="fas fa-angle-down"></i></a>
                                    <ul class="sub-menu shape-none" id="submenu-3">
                                        <li class="sub-menu--item">
                                            <a href="blog.php">
                                                <span class="menu-item-text">Our Blog</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="blog-grid.php">
                                                <span class="menu-item-text">Blog grid</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-blog.php">
                                                <span class="menu-item-text">blog details</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Service<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-4">
                                        <li class="sub-menu--item">
                                            <a href="service.php">
                                                <span class="menu-item-text">service</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-service.php">
                                                <span class="menu-item-text">service details</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Team<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-5">
                                        <li class="sub-menu--item">
                                            <a href="team.php">
                                                <span class="menu-item-text">team</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-team.php">
                                                <span class="menu-item-text">team details</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Portfolio<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-6">
                                        <li class="sub-menu--item">
                                            <a href="portfolio-02.php">
                                                <span class="menu-item-text">Portfolio One Column</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="portfolio-01.php">
                                                <span class="menu-item-text">Portfolio Two Column</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="single-portfolio.php">
                                                <span class="menu-item-text">Single Portfolio</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Utility<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-7">
                                        <li class="sub-menu--item">
                                            <a href="faq.php">
                                                <span class="menu-item-text">faq</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="errors-404.php">
                                                <span class="menu-item-text">Error 404</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="testimonial.php">
                                                <span class="menu-item-text">testimonial</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="coming-soon.php">
                                                <span class="menu-item-text">Coming Soon</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="sub-menu--item nav-item-has-children">
                                    <a href="#" data-menu-get="h3" class="drop-trigger">Account<i class="fas fa-angle-down"></i>
                                    </a>
                                    <ul class="sub-menu shape-none" id="submenu-8">
                                        <li class="sub-menu--item">
                                            <a href="sign-up.php">
                                                <span class="menu-item-text">sign up</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="sign-in.php">
                                                <span class="menu-item-text">sign in</span>
                                            </a>
                                        </li>
                                        <li class="sub-menu--item">
                                            <a href="reset-password.php">
                                                <span class="menu-item-text">reset password</span>
                                            </a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item nav-item-has-children">
                            <a href="#" class="nav-link-item drop-trigger">Blog <i class="fas fa-angle-down"></i></a>
                            <ul class="sub-menu" id="submenu-9">
                                <li class="sub-menu--item">
                                    <a href="blog.php">
                                        <span class="menu-item-text">blog</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="blog-grid.php">
                                        <span class="menu-item-text">Blog grid</span>
                                    </a>
                                </li>
                                <li class="sub-menu--item">
                                    <a href="single-blog.php">
                                        <span class="menu-item-text">blog Details</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a href="contact-us.php" class="nav-link-item">Contact Us</a>
                        </li>
                    </ul>
                </nav>
            </div>

            <div class="header-btn header-btn-l1 ms-auto d-none d-xs-inline-flex">
                <a class="aximo-default-btn pill aximo-header-btn" href="contact-us.php">
                    Contact Us
                </a>
            </div>
            <!-- mobile menu trigger -->
            <div class="mobile-menu-trigger light">
                <span></span>
            </div>
            <!--/.Mobile Menu Hamburger Ends-->
        </nav>
    </div>
</header>
<!--End landex-header-section -->