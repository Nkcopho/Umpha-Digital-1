<div class="aximo-preloader-wrap">
    <div class="aximo-preloader">
      <div></div>
      <div></div>
      <div></div>
      <div></div>
    </div>
  </div>