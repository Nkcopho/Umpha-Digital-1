<?php include './partials/script.php' ?>

</body>

</html>